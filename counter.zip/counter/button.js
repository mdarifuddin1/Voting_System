const redtitle = document.getElementById('redtitle');
const redButton = document.getElementById('red-button');
const greentitle = document.getElementById('greentitle');
const greenButton = document.getElementById('green-button');
const bluetitle = document.getElementById('bluetitle');
const blueButton = document.getElementById('blue-button');
const totalClicksElement = document.getElementById('total-clicks');
const refreshButton = document.getElementById('refresh-button');
const winnerElement = document.getElementById('winner');

let redCount = 0;
let greenCount = 0;
let blueCount = 0;
let totalClicks = 0;

redButton.addEventListener('click', () => {
  redCount++;
  totalClicks++;
  redtitle.textContent = redCount;
  totalClicksElement.textContent = totalClicks;
  checkWinner();
});

greenButton.addEventListener('click', () => {
  greenCount++;
  totalClicks++;
  greentitle.textContent = greenCount;
  totalClicksElement.textContent = totalClicks;
  checkWinner();
});

blueButton.addEventListener('click', () => {
  blueCount++;
  totalClicks++;
  bluetitle.textContent = blueCount;
  totalClicksElement.textContent = totalClicks;
  checkWinner();
});

refreshButton.addEventListener('click', () => {
  redCount = 0;
  greenCount = 0;
  blueCount = 0;
  totalClicks = 0;
  redButton.textContent = '0';
  greenButton.textContent = '0';
  blueButton.textContent = '0';
  totalClicksElement.textContent = '0';
  winnerElement.textContent = 'None';
  enableButtons();
});


function checkWinner() {
  if (totalClicks >= 30) {
    disableButtons();
    const winner = getWinner();
    winnerElement.textContent = winner;
  }
}


function getWinner() {
  if (redCount > greenCount && redCount > blueCount) {
    return 'Red';
  } else if (greenCount > redCount && greenCount > blueCount) {
    return 'Green';
  } else if (blueCount > redCount && blueCount > greenCount) {
    return 'Blue';
  } else if (blueCount == redCount || blueCount == greenCount || redCount == greenCoun) {
    return 'Multiple Winner';
  }else {
    return 'None';
  }
}


function disableButtons() {
  redButton.disabled = true;
  greenButton.disabled = true;
  blueButton.disabled = true;
}


function enableButtons() {
  redButton.disabled = false;
  greenButton.disabled = false;
  blueButton.disabled = false;
}